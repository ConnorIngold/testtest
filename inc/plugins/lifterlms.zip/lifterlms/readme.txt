=== LifterLMS ===
Contributors: thomasplevy, chrisbadgett, kathy11, lifterlms, codeboxllc
Donate link: https://lifterlms.com
Tags: learning management system, LMS, membership, elearning, online courses, quizzes, sell courses, badges, gamification, learning, Lifter, LifterLMS
Requires at least: 4.0
Tested up to: 4.9.4
Stable tag: 3.16.13
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

LifterLMS, the #1 WordPress LMS solution, makes it easy to create, sell, and protect engaging online courses.


== Description ==

LifterLMS is a powerful WordPress LMS plugin that makes it easy to create, sell, and protect engaging online courses. The mission of LifterLMS is to democratize education in the digital classroom.

https://www.youtube.com/watch?v=LugJPS7bhxI


# **Extend and Enhance LifterLMS with Add-ons**

#### **Advanced**

_Courses + Community + Coaching = Engagement_

+ [LifterLMS Private Areas][pa]
+ [LifterLMS Social Learning][sl]

#### **Integrations**

_Integrate with the third-party tools you know and love_

+ [LifterLMS Stripe][stripe]
+ [LifterLMS PayPal][pp]
+ [LifterLMS Authorize.Net][anet]
+ [LifterLMS WooCommerce][wc]
+ [LifterLMS ConvertKit][ck]
+ [LifterLMS MailChimp][mc]

#### **Design Tools**

_Make your learning platform beautiful_

+ [LifterLMS Pro][pro]
+ [LifterLMS LaunchPad Theme][lp]

#### **Support**

_Our world-class support has your back_

+ [LifterLMS Pro][pro]
+ [LifterLMS Office Hours][oh]

#### **Save Big with a Bundle**

_Save money while unlocking the full potential of your learning platform_

+ [Infinity Bundle][infinity]
+ [Universe Bundle][universe]


# **Give LifterLMS a Try**

_Try LifterLMS and the premium add-ons before investing any time_

+ [Try LifterLMS for $1][try]
+ [Take a Free Course][demo]


# **[LifterLMS Features][features]**

_With LifterLMS and LifterLMS Add-ons you can..._

#### **Create Courses**

+ Multimedia lessons
+ Quizzes
+ Course builder
+ Drip Content
+ Pre-requisites
+ Course tracks
+ Assignments (coming soon)
+ Quiz time limits
+ Student dashboard
+ Multi-instructor
+ Lesson downloads
+ Course import & export
+ Discussion areas
+ Instructional design
+ Forum integrations
+ Graphics pack
+ Course reviews

#### **Build an Education-Based Business**

+ Credit card payments
+ One-time payments
+ Recurring payments
+ Payment plans
+ Unlimited pricing models
+ PayPal
+ Subscriptions
+ Checkout
+ Free courses
+ Course bundles
+ Private coaching upsells
+ Coupons
+ Bulk sales
+ Affiliate ready
+ Native sales pages
+ Offline sales
+ Customizable enrollment
+ Country and currency
+ E-commerce dashboard
+ Credit card management
+ Subscription switching
+ Payment switching

#### **Engage Your Students**

+ Achievement bages
+ Certificates
+ Peronalized email
+ Social learning
+ Private coaching
+ Text messaging

#### **Offer Memberships**

+ Sitewide membership
+ Course bundles
+ Traditional memberships
+ Automatic course enrollment
+ Bulk course enrollment
+ Content restrictions
+ Members-only payment plans
+ Private group discussions
+ Members-only forums

#### **Integrate with the Tools You Need**

+ Payment gateways
+ Email marketing
+ Forums
+ Mobile friendly
+ Use any theme
+ Built for compatibility
+ CRMs
+ E-learning authoring tools
+ Tin Can API (xAPI)

#### **Secure and Protect Your Content**

+ Course protection
+ User account management and registration
+ Members-only content
+ Restricted access
+ Password management
+ Self-hosted

#### **Own and Manage Your Platform**

+ Detailed reporting
+ Gradebook
+ Email notifications
+ Bulk enrollments
+ Student management
+ Access management
+ Web design management
+ Branding & Typography
+ LMS Roles
+ Security
+ Require terms
+ Scaleable
+ Layout
+ Testing tools

#### **Get Support**

+ Technical support
+ Live office hours
+ Free training courses
+ Setup wizard
+ Detailed documentation
+ Dynamic resources
+ Demo course
+ System analyzer
+ User community
+ Developer ecosystem

#### **Further Reading**

+ The [LifterLMS Official Homepage][home]
+ The [LifterLMS Knowledgebase][docs]
+ The [LifterLMS Blog][blog]
+ The [LifterLMS Podcast][podcast]


# **Join Our Growing Community**

When you download LifterLMS, you join a thriving community of education entrepreneurs, developers, and WordPress enthusiasts. We’re one of the fastest growing open source eLearning communities online, and you are welcome here.

If you’re interested in contributing to LifterLMS, head over to the [LifterLMS GitHub Repository][git] to find out how you can pitch in.

Want to add a new language to LifterLMS? Swell! You can contribute at [translate.wordpress.org][translate].

Also I'd like to invite you to the [LifterLMS VIP Facebook group][facebook] so you can check out what other LifterLMS users are up to and ask questions to the community.


[home]: https://lifterlms.com/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[docs]: https://lifterlms.com/docs/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[blog]: http://blog.lifterlms.com/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[podcast]: http://podcast.lifterlms.com/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[git]: https://github.com/gocodebox/lifterlms/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[demo]: https://demo.lifterlms.com/course/how-to-build-a-learning-management-system-with-lifterlms/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[translate]: https://translate.lifterlms.com/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[facebook]: https://www.facebook.com/groups/lifterlmsvip/

[anet]: https://lifterlms.com/product/authorize-net/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[dfy]: https://lifterlms.com/dfy/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[ck]: https://lifterlms.com/product/lifterlms-convertkit/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[infinity]: https://lifterlms.com/product/infinity-bundle/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[lp]: https://lifterlms.com/product/launchpad/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[mc]: https://lifterlms.com/product/mailchimp-extension/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[oh]: https://lifterlms.com/product/office-hours/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[pa]: https://lifterlms.com/product/private-areas/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[pp]: https://lifterlms.com/product/paypal-extension/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[pro]: https://lifterlms.com/product/lifterlms-pro/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[sl]: https://lifterlms.com/product/social-learning/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[stripe]: https://lifterlms.com/product/stripe-extension/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[try]: https://lifterlms.com/product/try/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[universe]: https://lifterlms.com/product/universe-bundle/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[wc]: https://lifterlms.com/product/woocommerce-extension/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale

[features]: https://lifterlms.com/features/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[feature-lms]: https://lifterlms.com/features/lms/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[feature-ecomm]: https://lifterlms.com/features/e-commerce/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[feature-membership]: https://lifterlms.com/features/membership/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale
[feature-engagement]: https://lifterlms.com/features/engagement/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale


== Installation ==

#### Minimum System Requirements

LifterLMS Requires

+ PHP 5.6 or later
+ MySQL 5.6 or later
+ WordPress 4.0 or later

Visit our [full system requirements](https://lifterlms.com/docs/minimum-system-requirements-lifterlms/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale) for additional information.

#### Automatic Installation

This is the simplest way to install LifterLMS as it utilizes WordPress to handle file transfers and you never need to leave the web browser or admin panel.

1. Log in to your WordPress dashboard.
2. Navigate to Plugins -> Add New
3. In the search field type "LifterLMS" and click "Search Plugins"
4. Once you've located LifterLMS click "Install Now"
5. Once installation is complete, click "Activate"

#### Manual Installation

To manually install LifterLMS you'll need to download the zip file using the "Download" link on this screen. You'll then need to use FTP to manually upload the files to the proper directory on your webserver.

Please see this [WordPress Codex document](https://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation) for full instruction on Manual Plugin Installation.


#### Setup Wizard

After installing LifterLMS for the first time you will be redirected to the Setup Wizard. This wizard will walk quickly configure LifterLMS so you can get to course creating as quickly as possible. At the conclusion you'll have the option to import a sample course.

You can return to the setup wizard at any time by following [these steps](https://lifterlms.com/docs/rerun-lifterlms-setup-wizard/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).


== Frequently Asked Questions ==

#### Are there any troubleshooting steps you'd suggest I try that might resolve my issue before I post a new thread?

First, make sure that you're running the latest version of LifterLMS. And if you've got any other LifterLMS extensions or themes, make sure those are running the most current version as well.

The most common issues we see are either plugin conflicts, theme conflicts, or outdated servers. You can test if a plugin or theme is conflicting by manually deactivating other plugins until just LifterLMS is running on your site. If the issue persists from there, revert to the default Twenty Fifteen theme. If the issue is resolved after deactivating a specific plugin or your theme, you'll know that is the source of the conflict. If it is a hosting issue, contact your web host and make sure they’re running the most current version of PHP.

Also be sure to check out the official LifterLMS [Knowledge Base](https://lifterlms.com/docs/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).


#### I'm still stuck. Where do I go to file a bug or ask a question?

Users of the free LifterLMS should post their questions in the plugin's WordPress.org forum. If you find you're not getting support in as timely a fashion as you wish, you might want to consider purchasing a [LifterLMS Pro license](https://lifterlms.com/product/lifterlms-pro/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).

If you're already a LifterLMS Pro user or you have purchased one of the LifterLMS themes or extensions, you're entitled to log into your account and contact the support team directly on the [LifterLMS website](https://lifterlms.com/my-account/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale). We can provide a deeper level of support here and address your needs on a daily basis during the work week. Generally, except in times of increased support loads, we reply to all comments within 12 business hours.


#### LifterLMS is awesome! Can you set it all up for me?

Yes. You can get an instant quote for the team at LifterLMS to set everything up for you through our signature Done For You service. Get an instant quote through our automated quote generation tool on the [LifterLMS website services page](https://lifterlms.com/dfy/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).


#### I'm interested in LifterLMS Pro, another LifterLMS extension, or a LifterLMS theme, but there are a few questions I've got before making the purchase. Can you help me get those addressed?

Absolutely. If you're not finding your questions answered on the product pages, you can ask your presales questions through this [contact form](https://lifterlms.com/contact/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale). You can also connect live with a member of our team [here](https://lifterlms.com/contact/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).


#### What add-ons are available for LifterLMS, and where can I read more about them?

You can find a full list of officlai LifterLMS Add-ons [here](https://lifterlms.com/store/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale)


#### I have a feature idea. What's the best way to tell you about it?

We care about your feature ideas and what you have to say. You can [request a feature](https://lifterlms.com/contact/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale), [vote on existing feature requests](?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale), and checkout the [product roadmap](https://lifterlms.com/roadmap/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).


#### I still have questions. Where can I find answers?

Be sure you’ve taken the free tutorial training video course: [How to Create an Online Course with LifterLMS](http://demo.lifterlms.com/course/how-to-build-a-learning-management-system-with-lifterlms/?utm_source=LifterLMS%20Plugin&utm_medium=README&utm_campaign=Readme%20to%20Sale).


== Screenshots ==

1. LifterLMS Courses
2. LifterLMS Pricing Tables
3. LifterLMS Checkout
4. LifterLMS Lessons
5. LifterLMS Achievement Earned
6. LifterLMS Achievement Badges
7. LifterLMS Quiz Results
8. LifterLMS Student Dashboard
9. LifterLMS Certificates
10. LifterLMS Sales Reporting
11. LifterLMS Student Reporting
12. LifterLMS Enrollment Reporting
13. LifterLMS Sidebar Widgets
14. LifterLMS Subscription Management
15. LifterLMS Settings
16. LifterLMS Course Builder
17. LifterLMS Lesson Settings
18. LifterLMS Engagements
19. LifterLMS Email Engagements
20. LifterLMS Course Access Plans
21. LifterLMS Update Upcoming Order Details
22. LifterLMS Lock Down Non LMS Content with Memberships
23. LifterLMS Membership Course Bundles and Auto Enrollment
24. LifterLMS Business to Business Bulk Enrollment Activations with Vouchers


== Changelog ==


= v3.16.13 - 2018-02-28 =
-------------------------

+ Hotfix: Only create quizzes on the builder if quizzes exist on the lesson

= v3.16.12 - 2018-02-27 =
-------------------------

+ Quizzes can now be detached (removed from a lesson) or deleted (deleted from the lesson and the database) via the Course Builder
+ Improved question choice randomization to ensure randomized choices never display in their original order.
+ When a lesson is deleted, any quiz attached to the lesson will become an orphan
+ When a lesson is deleted, any lesson with this lesson as a prerequisite will have it's prerequisite data removed
+ When a quiz is deleted, all questions attached to the quiz will also be deleted
+ When a quiz is deleted, the lesson associated with the quiz will have those associations removed
+ Fixed grammar issue on restricted lesson tooltips when no custom message is stored on the course.
+ Updated functions causing issues in PHP 5.4 to work on PHP 5.4. This has been done to reduce frustration for users still using PHP 5.4 and lower; [This does not mean we advocate using software past the end of its life or that we support PHP 5.4 and lower](https://lifterlms.com/docs/minimum-system-requirements-lifterlms/).


= v3.16.11 - 2018-02-22 =
-------------------------

+ Course import/exports and lesson duplication now carry custom meta data from 3rd party plugins and themes
+ Added course completion date column to Course reporting students list
+ Restriction checks made against a quiz will now properly cascade to the quiz's parent lesson
+ Fixed issue preventing featured images from being exported with courses and lessons
+ Fixed duplicate lesson issue causing quizzes to be double assigned to the old and new lesson
+ Fixed issue allowing blog archive to be viewed by non-members when sitewide membership is enabled
+ Fixed builder issue causing data to be lost during autosaves if data was edited during an autosave
+ Fixed builder issue preventing lessons from moving between sections when clicking the "Prev" and "Next" section buttons
+ Added actions to `LLMS_Generator` to allow 3rd parties to extend core generator functionality


= v3.16.10 - 2018-02-19 =
-------------------------

+ Content added to the editor of course & membership catalog pages will now be output *above* the catalog loop
+ Fix issue preventing iframes and some shortcodes from working when added to a Quiz question description
+ Added new columns to the Quizzes reporting table to display Course and Lesson relationships
+ Improved the task handler of background updater to ensure upgrade functions that need to run multiple times can do so
+ Fixed JS Backup confirmation dialog on the background updater.
+ Add support for 32-bit systems in the `LLMS_Hasher` class
+ Fix issue causing HTML template content to be added to lessons when duplicating an existing lesson within the course builder

##### 3.16.0 migration improvements

+ Accommodates questions imported by 3rd party Excel to LifterLMS Quiz plugin. Fixes an issue where choices would have no correct answer designated after migration.
+ All migration functions now run on a loop. This improves progress reporting of the migration and prevents timeouts on mature databases with lots of quizzes, questions, and/or attempts.
+ Fix an issue that caused duplicate quizzes or questions to be created when the "Taking too long?" link was clicked


= v3.16.9 - 2018-02-15 =
------------------------

+ Fix issue causing error on student dashboard when reviewing an order with an access plan that was deleted.
+ Fixed spelling error on course metabox
+ Fixed spelling error on frontend quiz interface
+ Fixed issues with 0 point questions:
  + Will no longer prevent quizzes from being automatically graded when a 0 point question is in an otherwise automatically gradeable quiz
  + Point value not editable during review
  + Visual display on results displays with grey background not as an orange "pending" question
+ Table schema uses default database charset. Fixes an issue with databases that don't support `utf8mb4` charsets.
+ Updated `LLMS_Hasher` class for better compatibility with older versions of PHP


= v3.16.8 - 2018-02-13 =
------------------------

##### Updates

+ Added theme compatibility API so theme developers can add layout options to the quiz settings on the course builder. For details on adding theme compatibility see: [https://lifterlms.com/docs/quiz-theme-compatibility-developers/](https://lifterlms.com/docs/quiz-theme-compatibility-developers/).
+ Quiz results "donut" chart had alternate styles for quizzes pending review (Dark grey text rather than red). You can target with the `.llms-donut.pending` CSS class to customize appearance.
+ Allow filtering when retrieving student answer for a quiz attempt question via `llms_quiz_attempt_question_get_answer` filter

##### Bug Fixes

+ Fix issues causing conditionally gradeable question types (fill in the blank and scale) from displaying without a status icon or possible points when awaiting admin review / grading.
+ Fix issue preventing conditionally gradeable question types (fill in the blank and scale) from being reviewable on the admin panel when the question is configured as requiring manual grading.
+ Fix analytics widget undefined index warning during admin-ajax calls. Thanks [@Mte90](https://github.com/Mte90)!
+ Fix issue causing `is_search()` to be called incorrectly. Thanks [@Mte90](https://github.com/Mte90)!
+ Fix issue preventing text / html formatting from saving properly for access plan description fields
+ Fix html character encoding issue on reporting widgets causing currency symbols to display as a charcter code instead of the symbol glyph.

##### Templates changed

+ templates/quiz/results-attempt-questions-list.php
+ templates/quiz/results-attempt.php


= v3.16.7 - 2018-02-08 =
------------------------

+ Added manual saving methods for the course builder that passes data via standard ajax calls. Allows users (hosts) to disable the Heartbeat API but still save builder data.
+ Added an "Exit" button to the builder sidebar to allow exiting the builder back to the WP Edit Post screen for the current course
+ Added dashboard links to the WP Admin Bar to allow existing the course builder to various areas of the dashboard
+ Added data attribute to progress bars so JS (or CSS) can read the progress of a progress bar. Thanks [@dineshchouhan](https://github.com/dineshchouhan)!
+ Fixed issue causing newly created lessons to lose their assigned quiz
+ Fixed php `max_input_vars` issue causing a 400 Bad Request error when trying to save large courses in the course builder
+ Removed reliance on PHP bcmath functions


= v3.16.6 - 2018-02-07 =
------------------------

+ Removed reliance on PHP Hashids Library in favor of a simpler solution with no PHP module dependencies
+ Added interfaces to allow customization of quiz url / slug
+ Fixed [audio] shortcodes added to quiz question descrpitions
+ Fixed untranslateable strings on frontend of quizzes
+ Fix issue causing certificate notifications to display as empty
+ Fix issue preventing quiz pass/fail notifications from triggering properly for manually graded quizzes
+ Fix undefined index warning on quiz pass/fail notifications


= v3.16.5 - 2018-02-06 =
------------------------

+ Fix issue preventing manually graded quiz review points from saving properly
+ Improved background updater to ensure scripts don't timeout during upgrades
+ Admin builder JS now minified for increased performance
+ Made frontend quiz and quiz-builder strings output via Javascript translateable


= v3.16.4 - 2018-02-05 =
------------------------

+ Fix issue causing newly created quizzes to not be properly related to their parent lesson
+ Fix issue preventing quiz time limits from starting unless an attempt limit is also set
+ Fixes a WP Engine issue that prevented the builder from loading due to a blocked dependency


[View the full changelog](https://github.com/gocodebox/lifterlms/blob/master/CHANGELOG.md#lifterlms-changelog)
