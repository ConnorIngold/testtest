<?php
/**
 * LifterLMS Single Quiz Before
 * @since   1.0.0
 * @version 3.16.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

llms_print_notices();

do_action( 'lifterlms_single_quiz_before_summary' );
