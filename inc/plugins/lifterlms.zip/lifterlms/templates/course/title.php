<?php
/**
 * @author 		codeBOX
 * @package 	lifterLMS/Templates
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
?>

<h1 class="entry-title hentry-title llms-h1 llms-title"><?php the_title(); ?></h1>
