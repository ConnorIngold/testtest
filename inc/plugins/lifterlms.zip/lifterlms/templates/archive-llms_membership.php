<?php
/**
 * Template for displaying membership archives
 *
 * @author 		LifterLMS
 * @package 	LifterLMS/Templates
 * @since       1.0.0
 * @version     3.0.0
 *
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

llms_get_template( 'loop.php' );
