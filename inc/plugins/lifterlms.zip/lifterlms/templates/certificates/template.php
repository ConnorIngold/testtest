<?php

if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<p><?php echo $email_message; ?></p>
