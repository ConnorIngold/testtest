<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<p class="lifterlms-info"><?php _e( 'No products were found matching your selection.', 'lifterlms' ); ?></p>
