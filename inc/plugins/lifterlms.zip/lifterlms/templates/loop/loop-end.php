<?php
/**
 * LifterLMS Loop End Wrapper
 *
 * @since   1.0.0
 * @version 3.0.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } // End if().
?>
	</ul>
</div><!-- .llms-loop -->
