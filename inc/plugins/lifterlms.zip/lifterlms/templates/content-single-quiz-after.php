<?php
/**
 * LifterLMS Single Quiz After
 * @since   1.0.0
 * @version 3.16.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

do_action( 'lifterlms_single_quiz_after_summary' );
