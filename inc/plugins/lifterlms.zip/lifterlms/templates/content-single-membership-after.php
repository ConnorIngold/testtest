<?php
/**
 * The Template for displaying all single membership.
 *
 * @author 		codeBOX
 * @package 	lifterLMS/Templates
 *
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

do_action( 'lifterlms_single_membership_after_summary' );


