(function ( $ ) {
	window.InlineShortcodeView_vc_column_inner = window.InlineShortcodeView_vc_column.extend( {} );
})( window.jQuery );